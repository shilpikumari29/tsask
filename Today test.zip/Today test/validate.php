<?php

$errors = array();
if(empty($_POST["fullname"]))
{
    $errors["fullname"] ='full name is rquired';

}elseif(!preg_match("/^[a-zA-Z/s]+$/ $_post["fullname"])){
    $errors ["fullname"]= "fullname";


}
if(empty($_POST["phone"]))
{
    $errors["phone"] ='phone is rquired';

}elseif(!preg_match("/^[a-zA-Z/s]+$/ $_post["phone"])){
    $errors ["phone]= "phone number ";


}if(empty($_POST["Email"]))
{
    $errors["Email"] ='Email is rquired';

}elseif(!preg_match("/^[a-zA-Z/s]+$/ $_post["Email"])){
    $errors ["Email"]]= "Email id";


}elseif(!
filter_var($_post["Email"],filter_validate_Email)){
    $errors["Email"] ="invalid";
}
 if(empty($errors)){
    echo "form sumitted successfully";
 }
 
 //check the connection

 <?php
$servername ="localhost";
$username = "Root";
$password = " ";
$dbname ="shilpi";


$conn= new mysqli($servername,$username,$password,$dbname);
  

  if ($conn->connect_error){
    die("connection failed: "$conn->connect_error);
   }

   $fullname= $conn->real_escape_string($_post["fullname"]);
   $phone= $conn->real_escape_string($_post["phone"]);
   $Email= $conn->real_escape_string($_post["Email"]);
   $subject= $conn->real_escape_string($_post["subject"]);

   //data insert
   $sql = "insert into contact_form(Full Name,Phone Number,Email,Subject,Message) values($fullname,$phone,$Email,$subject,$massge);






?>